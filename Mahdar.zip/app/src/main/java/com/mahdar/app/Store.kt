package com.mahdar.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File

object Store {
    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    val meetings = MutableStateFlow<List<Meeting>>(emptyList())

    @Synchronized
    fun init(ctx: Context) {
        if (::dir.isInitialized) return
        dir = File(ctx.filesDir, "meetings").apply { mkdirs() }
        prefs = ctx.getSharedPreferences("mahdar", Context.MODE_PRIVATE)
        reload()
        // Anything still "in progress" after a fresh process start was interrupted.
        meetings.value.filter { it.status == Status.RECORDING || it.status == Status.PROCESSING }.forEach {
            save(it.copy(status = Status.ERROR, statusText = ctx.getString(R.string.err_interrupted)))
        }
    }

    private fun reload() {
        meetings.value = dir.listFiles { f -> f.extension == "json" }.orEmpty()
            .mapNotNull { f -> runCatching { meetingFromJson(JSONObject(f.readText())) }.getOrNull() }
            .sortedByDescending { it.createdAt }
    }

    @Synchronized
    fun save(m: Meeting) {
        File(dir, "${m.id}.json").writeText(m.toJson().toString())
        reload()
    }

    fun get(id: String): Meeting? = meetings.value.firstOrNull { it.id == id }

    @Synchronized
    fun delete(ctx: Context, id: String) {
        File(dir, "$id.json").delete()
        Pipeline.segDir(ctx, id).deleteRecursively()
        Pipeline.outDir(ctx, id).deleteRecursively()
        reload()
    }

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) { prefs.edit().putString("key", v.trim()).apply() }
}
