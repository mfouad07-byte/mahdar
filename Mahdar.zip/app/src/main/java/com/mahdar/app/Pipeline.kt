package com.mahdar.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UserFacing(msg: String) : Exception(msg)

object Pipeline {
    fun segDir(ctx: Context, id: String): File = File(ctx.filesDir, "audio/$id").apply { mkdirs() }
    fun outDir(ctx: Context, id: String): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Mahdar/$id").apply { mkdirs() }

    private fun step(m: Meeting, text: String): Meeting =
        m.copy(status = Status.PROCESSING, statusText = text).also { Store.save(it) }

    suspend fun run(ctx: Context, id: String) {
        var m = Store.get(id) ?: return
        val key = Store.apiKey
        if (key.isBlank()) throw UserFacing(ctx.getString(R.string.err_no_key))
        val segs = segDir(ctx, id).listFiles { f -> f.name.endsWith(".m4a") && f.length() > 2000 }
            ?.sortedBy { it.name }.orEmpty()
        if (segs.isEmpty()) throw UserFacing(ctx.getString(R.string.err_no_speech))

        val client = GeminiClient(key)
        val all = mutableListOf<Line>()
        var offset = 0
        for ((i, f) in segs.withIndex()) {
            m = step(m, ctx.getString(R.string.st_transcribing, i + 1, segs.size))
            val dur = AudioTools.durationSec(f).let { if (it <= 0) 600 else it }
            val cache = File(f.path + ".json") // lets Retry skip parts that already succeeded
            val raw = if (cache.exists()) cache.readText() else {
                val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                val parts = JSONArray()
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/mp4").put("data", b64)))
                    .put(JSONObject().put("text", Prompts.transcript(all.map { it.speaker }.distinct())))
                client.generate(parts).also { cache.writeText(it) }
            }
            all += Parsing.parseTranscript(Parsing.extractJson(raw), offset)
            offset += dur
        }
        if (all.isEmpty()) throw UserFacing(ctx.getString(R.string.err_no_speech))

        m = step(m, ctx.getString(R.string.st_analyzing))
        val tx = all.joinToString("\n") { "[${Parsing.formatTime(it.timeSec)}] ${it.speaker}: ${it.text}" }
        val today = SimpleDateFormat("EEEE yyyy-MM-dd", Locale.US).format(Date())
        val a = Parsing.parseAnalysis(
            Parsing.extractJson(
                client.generate(JSONArray().put(JSONObject().put("text", Prompts.analysis(tx, today))))
            )
        )

        m = step(m, ctx.getString(R.string.st_finishing))
        val title = a.title.ifBlank { m.title }
        val stamp = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date(m.createdAt))
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(m.createdAt))
        val out = outDir(ctx, id)
        val audioFile = File(out, "Mahdar_${stamp}_audio.m4a")
        val merged = try { AudioTools.merge(segs, audioFile); true } catch (e: Exception) { audioFile.delete(); false }
        val tPdf = File(out, "Mahdar_${stamp}_transcript.pdf")
        val mPdf = File(out, "Mahdar_${stamp}_minutes.pdf")
        Pdfs.transcript(title, date, all, tPdf)
        Pdfs.minutes(title, date, a, mPdf)
        val audioPath = if (merged) audioFile.path else segs.first().path
        if (merged) segs.forEach { it.delete(); File(it.path + ".json").delete() }

        Store.save(
            m.copy(
                title = title, durationSec = offset, status = Status.DONE, statusText = "",
                audioPath = audioPath, transcriptPdf = tPdf.path, minutesPdf = mPdf.path,
                lines = all, summary = a.summary, attendees = a.attendees, topics = a.topics,
                decisions = a.decisions, actions = a.actions,
            )
        )
    }
}
