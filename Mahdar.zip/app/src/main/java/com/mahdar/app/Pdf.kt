package com.mahdar.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

private val TEAL = Color.rgb(15, 76, 92)
private val GRAY = Color.rgb(90, 90, 90)

/** Minimal multi-page PDF writer with Arabic / RTL-aware text layout. */
class PdfWriter {
    private val doc = PdfDocument()
    private val pageW = 595
    private val pageH = 842
    private val margin = 40
    private val width get() = pageW - 2 * margin
    private var page: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var y = 0f
    private var count = 0

    private fun newPage() {
        page?.let { doc.finishPage(it) }
        count++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, count).create())
        page = p
        canvas = p.canvas
        y = margin.toFloat()
    }

    fun text(s: String, size: Float = 11f, bold: Boolean = false, color: Int = Color.BLACK, gap: Float = 4f) {
        if (s.isBlank()) return
        if (page == null) newPage()
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        val layout = StaticLayout.Builder.obtain(s, 0, s.length, paint, width)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.2f)
            .build()
        for (i in 0 until layout.lineCount) {
            val top = layout.getLineTop(i)
            val bottom = layout.getLineBottom(i)
            if (y + (bottom - top) > pageH - margin) newPage()
            val c = canvas!!
            c.save()
            c.translate(margin.toFloat(), y - top)
            c.clipRect(0f, top.toFloat(), width.toFloat(), bottom.toFloat())
            layout.draw(c)
            c.restore()
            y += (bottom - top)
        }
        y += gap
    }

    fun space(v: Float = 8f) { y += v }

    fun save(f: File) {
        if (page == null) newPage()
        page?.let { doc.finishPage(it) }
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
    }
}

object Pdfs {
    fun transcript(title: String, date: String, lines: List<Line>, out: File) {
        val w = PdfWriter()
        w.text("Mahdar  |  محضر", 10f, true, GRAY)
        w.text(title, 20f, true, TEAL, 2f)
        w.text(date, 10f, false, GRAY, 12f)
        var last = ""
        for (l in lines) {
            val head = if (l.speaker == last) "" else "${l.speaker}  •  ${Parsing.formatTime(l.timeSec)}"
            if (head.isNotEmpty()) { w.space(4f); w.text(head, 9f, true, TEAL, 1f) }
            w.text(l.text, 11f, false, Color.BLACK, 3f)
            last = l.speaker
        }
        w.save(out)
    }

    fun minutes(title: String, date: String, a: Analysis, out: File) {
        val w = PdfWriter()
        w.text("Mahdar  |  محضر", 10f, true, GRAY)
        w.text(title, 20f, true, TEAL, 2f)
        w.text(date, 10f, false, GRAY, 12f)
        w.text("Summary | الملخص", 14f, true, TEAL)
        w.text(a.summary, 11f, false, Color.BLACK, 10f)
        if (a.attendees.isNotEmpty()) {
            w.text("Attendees | الحضور", 14f, true, TEAL)
            w.text(a.attendees.joinToString("، "), 11f, false, Color.BLACK, 10f)
        }
        if (a.topics.isNotEmpty()) {
            w.text("Minutes of Meeting | محضر الاجتماع", 14f, true, TEAL)
            a.topics.forEach { t ->
                w.text(t.title, 12f, true, Color.BLACK, 2f)
                t.points.forEach { w.text("•  $it", 11f, false, Color.BLACK, 2f) }
                w.space(6f)
            }
        }
        if (a.decisions.isNotEmpty()) {
            w.text("Decisions | القرارات", 14f, true, TEAL)
            a.decisions.forEach { w.text("•  $it", 11f, false, Color.BLACK, 2f) }
            w.space(8f)
        }
        w.text("Action Items | المهام", 14f, true, TEAL)
        if (a.actions.isEmpty()) w.text("—")
        a.actions.forEachIndexed { i, x ->
            w.text("${i + 1}.  ${x.task}", 11f, true, Color.BLACK, 1f)
            val meta = listOf(
                if (x.owner.isNotBlank()) "Owner / المسؤول: ${x.owner}" else "",
                if (x.due.isNotBlank()) "Due / الموعد: ${x.due}" else "",
                if (x.priority.isNotBlank()) "Priority / الأولوية: ${x.priority}" else "",
            ).filter { it.isNotEmpty() }.joinToString("   ")
            w.text(meta, 9.5f, false, GRAY, 8f)
        }
        w.save(out)
    }
}
