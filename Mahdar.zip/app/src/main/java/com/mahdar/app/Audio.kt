package com.mahdar.app

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

object AudioTools {
    fun durationSec(f: File): Int = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.path)
        val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        (ms / 1000).toInt()
    } catch (e: Exception) {
        0
    }

    /** Concatenates AAC/M4A files into one M4A without re-encoding. */
    fun merge(files: List<File>, out: File) {
        if (files.size == 1) { files[0].copyTo(out, overwrite = true); return }
        out.delete()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var offsetUs = 0L
        try {
            for (f in files) {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(f.path)
                    var idx = -1
                    for (i in 0 until ex.trackCount) {
                        if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; break }
                    }
                    if (idx < 0) continue
                    ex.selectTrack(idx)
                    if (track < 0) { track = muxer.addTrack(ex.getTrackFormat(idx)); muxer.start(); started = true }
                    val buf = ByteBuffer.allocate(1 shl 20)
                    val info = MediaCodec.BufferInfo()
                    var lastUs = 0L
                    while (true) {
                        buf.clear()
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        lastUs = ex.sampleTime
                        info.set(0, size, offsetUs + lastUs, ex.sampleFlags)
                        muxer.writeSampleData(track, buf, info)
                        ex.advance()
                    }
                    offsetUs += lastUs + 23_000L
                } finally {
                    ex.release()
                }
            }
            if (!started) throw IllegalStateException("No audio track")
        } finally {
            if (started) runCatching { muxer.stop() }
            muxer.release()
        }
    }
}
