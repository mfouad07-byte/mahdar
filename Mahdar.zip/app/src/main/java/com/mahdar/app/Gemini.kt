package com.mahdar.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiException(val code: Int, message: String) : Exception(message)

class GeminiClient(private val key: String, private val model: String = "gemini-2.5-flash") {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .build()

    /** Sends [parts] and returns the model's text. Retries on rate limits / server errors. */
    suspend fun generate(parts: JSONArray): String = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.2))
            .toString()
        var result: String? = null
        var attempt = 0
        while (result == null) {
            attempt++
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            try {
                http.newCall(req).execute().use { resp ->
                    val txt = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        result = Parsing.responseText(txt)
                    } else if ((resp.code == 429 || resp.code >= 500) && attempt < 5) {
                        // fall through to wait + retry
                    } else {
                        throw GeminiException(resp.code, Parsing.errorMessage(txt))
                    }
                }
            } catch (e: IOException) {
                if (attempt >= 5) throw e
            }
            if (result == null) delay(15_000L * attempt)
        }
        result!!
    }
}

object Prompts {
    fun transcript(knownSpeakers: List<String>): String {
        val known = if (knownSpeakers.isEmpty()) "" else
            "Speakers already identified earlier in the same meeting: ${knownSpeakers.joinToString(", ")}. " +
                "Reuse the same label when you recognise the same voice. "
        return "You are a professional meeting transcriber. Transcribe this audio completely and accurately. " +
            "The speech is Arabic (any dialect, e.g. Egyptian) and/or English, often mixed inside the same sentence. " +
            "Write Arabic words in Arabic script and English words in Latin script exactly as spoken; never translate and never transliterate. " +
            "Identify each distinct speaker and label consistently as \"Speaker 1\", \"Speaker 2\", ... (or the real name if it is clearly said). " +
            known +
            "Start a new entry whenever the speaker changes. \"start\" is the time inside this clip formatted mm:ss. " +
            "Skip silence and noise. Return ONLY JSON: [{\"speaker\":\"\",\"start\":\"mm:ss\",\"text\":\"\"}]. If there is no speech return []."
    }

    fun analysis(transcript: String, today: String): String =
        "You are an expert meeting secretary. Below is a full meeting transcript (Arabic and/or English, possibly mixed). " +
            "Today's date is $today. Write the output in Arabic if the meeting is mainly Arabic (keep English terms in Latin script), otherwise in English. " +
            "Do not invent facts. Return ONLY JSON with this shape: " +
            "{\"title\":\"short meeting title\",\"summary\":\"1-2 paragraph summary\",\"attendees\":[\"names or Speaker labels\"]," +
            "\"topics\":[{\"title\":\"\",\"points\":[\"\"]}],\"decisions\":[\"\"]," +
            "\"actions\":[{\"task\":\"\",\"owner\":\"\",\"due\":\"date as YYYY-MM-DD if it can be resolved, otherwise the words used, otherwise empty\",\"priority\":\"High|Medium|Low\"}]}.\n\nTRANSCRIPT:\n$transcript"
}
