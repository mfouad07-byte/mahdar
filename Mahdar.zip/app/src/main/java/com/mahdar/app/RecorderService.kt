package com.mahdar.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecorderService : Service() {
    companion object {
        const val ACTION_START = "com.mahdar.app.START"
        const val ACTION_STOP = "com.mahdar.app.STOP"
        const val ACTION_PROCESS = "com.mahdar.app.PROCESS"
        const val EXTRA_ID = "id"
        const val SEGMENT_MS = 10 * 60 * 1000L // long meetings are cut into 10-minute parts
        private const val CHANNEL = "mahdar"
        val activeId = MutableStateFlow<String?>(null)
        val elapsed = MutableStateFlow(0)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Any()
    private var recorder: MediaRecorder? = null
    private var meetingId = ""
    private var segIndex = 0
    private var startedAt = 0L
    private var tickJob: Job? = null
    private var rotateJob: Job? = null
    private var wake: PowerManager.WakeLock? = null
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Store.init(applicationContext)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording()
            ACTION_STOP -> stopRecording()
            ACTION_PROCESS -> reprocess(intent.getStringExtra(EXTRA_ID))
            else -> if (activeId.value == null && !busy) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notif(text: String, withStop: Boolean, ongoing: Boolean = true): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setOnlyAlertOnce(true)
        if (withStop) {
            b.addAction(
                0, getString(R.string.notif_stop),
                PendingIntent.getService(this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE),
            )
        }
        return b.build()
    }

    private fun goForeground(text: String, mic: Boolean) {
        val type = if (Build.VERSION.SDK_INT >= 29) {
            if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else 0
        ServiceCompat.startForeground(this, 1, notif(text, mic), type)
    }

    private fun acquireWake() {
        if (wake?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahdar:work").apply { acquire(8 * 60 * 60 * 1000L) }
    }

    private fun releaseWake() { runCatching { if (wake?.isHeld == true) wake?.release() } }

    private fun startRecording() {
        if (activeId.value != null || busy) return
        val id = System.currentTimeMillis().toString()
        val title = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        Store.save(Meeting(id = id, title = title, createdAt = System.currentTimeMillis(), status = Status.RECORDING, statusText = getString(R.string.st_recording)))
        meetingId = id
        segIndex = 0
        elapsed.value = 0
        goForeground(getString(R.string.notif_recording), true)
        acquireWake()
        if (!startSegment()) { failRecording(id, getString(R.string.err_mic)); return }
        activeId.value = id
        startedAt = SystemClock.elapsedRealtime()
        tickJob = scope.launch {
            while (isActive) { delay(1000); elapsed.value = ((SystemClock.elapsedRealtime() - startedAt) / 1000).toInt() }
        }
        rotateJob = scope.launch {
            while (isActive) { delay(SEGMENT_MS); rotate() }
        }
    }

    private fun startSegment(): Boolean {
        val f = File(Pipeline.segDir(this, meetingId), "seg_%03d.m4a".format(Locale.US, segIndex++))
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(48000)
            r.setOutputFile(f.path)
            r.prepare()
            r.start()
            recorder = r
            true
        } catch (e: Exception) {
            f.delete()
            false
        }
    }

    private fun stopRecorder() {
        recorder?.let { runCatching { it.stop() }; runCatching { it.release() } }
        recorder = null
    }

    private fun rotate() {
        synchronized(lock) {
            if (activeId.value == null) return
            stopRecorder()
            if (!startSegment()) { scope.launch { stopRecording() } }
        }
    }

    private fun failRecording(id: String, msg: String) {
        Store.get(id)?.let { Store.save(it.copy(status = Status.ERROR, statusText = msg)) }
        activeId.value = null
        releaseWake()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopRecording() {
        val id = activeId.value ?: return
        tickJob?.cancel(); rotateJob?.cancel()
        synchronized(lock) { stopRecorder(); activeId.value = null }
        getSystemService(NotificationManager::class.java).notify(1, notif(getString(R.string.notif_processing), false))
        launchProcessing(id)
    }

    private fun reprocess(id: String?) {
        if (id == null || busy || activeId.value != null) return
        goForeground(getString(R.string.notif_processing), false)
        acquireWake()
        launchProcessing(id)
    }

    private fun launchProcessing(id: String) {
        busy = true
        Store.get(id)?.let { Store.save(it.copy(status = Status.PROCESSING, statusText = getString(R.string.notif_processing))) }
        scope.launch {
            var ok = false
            try {
                Pipeline.run(this@RecorderService, id)
                ok = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = when {
                    e is UserFacing -> e.message ?: ""
                    e is GeminiException && e.code == 429 -> getString(R.string.err_quota)
                    e is GeminiException && (e.code == 400 || e.code == 403) && (e.message ?: "").contains("API key", true) -> getString(R.string.err_key)
                    else -> getString(R.string.err_generic) + ": " + (e.message ?: e.javaClass.simpleName)
                }
                Store.get(id)?.let { Store.save(it.copy(status = Status.ERROR, statusText = msg)) }
            } finally {
                busy = false
                releaseWake()
                stopForeground(STOP_FOREGROUND_REMOVE)
                if (ok) {
                    getSystemService(NotificationManager::class.java).notify(2, notif(getString(R.string.notif_done), false, ongoing = false))
                }
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        synchronized(lock) { stopRecorder() }
        releaseWake()
        scope.cancel()
        super.onDestroy()
    }
}
