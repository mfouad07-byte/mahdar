@file:OptIn(ExperimentalMaterial3Api::class)

package com.mahdar.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private object C {
    val Teal = Color(0xFF0F4C5C)
    val Amber = Color(0xFFF5A524)
    val Paper = Color(0xFFFAF7F0)
    val Ink = Color(0xFF1B1B1B)
    val Red = Color(0xFFD64545)
    val Green = Color(0xFF2E7D32)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = C.Teal, secondary = C.Amber, background = C.Paper,
                    surface = Color.White, onBackground = C.Ink, onSurface = C.Ink,
                )
            ) {
                Box(Modifier.fillMaxSize().background(C.Paper)) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var screen by rememberSaveable { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }
    when {
        screen == "settings" -> SettingsScreen { screen = "home" }
        screen.startsWith("m:") -> DetailScreen(screen.removePrefix("m:")) { screen = "home" }
        else -> HomeScreen(onOpen = { screen = "m:$it" }, onSettings = { screen = "settings" })
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(C.Teal).padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
        }
        Text(
            title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
        )
        trailing()
    }
}

@Composable
fun statusLabel(s: Status): String = stringResource(
    when (s) {
        Status.RECORDING -> R.string.st_recording
        Status.PROCESSING -> R.string.st_processing
        Status.DONE -> R.string.st_done
        Status.ERROR -> R.string.st_error
    }
)

fun statusColor(s: Status): Color = when (s) {
    Status.DONE -> C.Green
    Status.ERROR -> C.Red
    else -> C.Amber
}

fun fmtDate(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(t))

@Composable
fun HomeScreen(onOpen: (String) -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val meetings by Store.meetings.collectAsState()
    val active by RecorderService.activeId.collectAsState()
    val elapsed by RecorderService.elapsed.collectAsState()
    val hasKey = Store.apiKey.isNotBlank()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, RecorderService::class.java).setAction(RecorderService.ACTION_START))
        } else {
            Toast.makeText(ctx, R.string.err_mic, Toast.LENGTH_LONG).show()
        }
    }
    val rec = active != null

    Column(Modifier.fillMaxSize()) {
        Header(stringResource(R.string.app_name)) {
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, null, tint = Color.White) }
        }
        if (!hasKey) {
            Box(Modifier.fillMaxWidth().background(C.Amber).clickable { onSettings() }.padding(14.dp)) {
                Text(stringResource(R.string.key_banner), color = C.Ink, fontWeight = FontWeight.Medium)
            }
        }
        if (meetings.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.no_meetings), color = Color.Gray)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(meetings, key = { it.id }) { m ->
                    Card(onClick = { onOpen(m.id) }, colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            val mins = if (m.durationSec > 0) "  •  ${maxOf(1, m.durationSec / 60)} ${stringResource(R.string.min)}" else ""
                            Text(fmtDate(m.createdAt) + mins, color = Color.Gray, fontSize = 13.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(statusLabel(m.status), color = statusColor(m.status), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(Color.White).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (rec) {
                Text(Parsing.formatTime(elapsed), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = C.Red)
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.size(84.dp).clip(CircleShape).background(if (rec) C.Red else C.Amber).clickable {
                    if (rec) {
                        ctx.startService(Intent(ctx, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
                    } else if (!hasKey) {
                        onSettings()
                    } else {
                        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                        launcher.launch(perms.toTypedArray())
                    }
                },
                contentAlignment = Alignment.Center,
            ) {
                if (rec) Box(Modifier.size(28.dp).background(Color.White, RoundedCornerShape(4.dp)))
                else Box(Modifier.size(30.dp).background(C.Teal, CircleShape))
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(if (rec) R.string.tap_stop else R.string.start_hint), color = Color.Gray, fontSize = 13.sp)
        }
    }
}

fun uriFor(ctx: Context, path: String): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))

fun openFile(ctx: Context, path: String, mime: String) {
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, path), mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(i) } catch (e: Exception) { Toast.makeText(ctx, "No app found", Toast.LENGTH_SHORT).show() }
}

fun shareFile(ctx: Context, path: String, mime: String) {
    val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uriFor(ctx, path)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, null))
}

@Composable
fun FileRow(label: String, path: String, mime: String) {
    if (path.isBlank() || !File(path).exists()) return
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontWeight = FontWeight.Medium)
        TextButton(onClick = { openFile(ctx, path, mime) }) { Text(stringResource(R.string.open)) }
        TextButton(onClick = { shareFile(ctx, path, mime) }) { Text(stringResource(R.string.share)) }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, color = C.Teal, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))

@Composable
fun DetailScreen(id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val meetings by Store.meetings.collectAsState()
    val m = meetings.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    if (m == null) { LaunchedEffect(Unit) { onBack() }; return }

    Column(Modifier.fillMaxSize()) {
        Header(m.title, onBack) {
            IconButton(onClick = { confirm = true }) { Icon(Icons.Filled.Delete, null, tint = Color.White) }
        }
        when (m.status) {
            Status.DONE -> {
                val tabs = listOf(R.string.tab_summary, R.string.tab_minutes, R.string.tab_actions, R.string.tab_transcript)
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp, containerColor = Color.White, contentColor = C.Teal) {
                    tabs.forEachIndexed { i, r -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(r)) }) }
                }
                if (tab == 3) {
                    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                        items(m.lines) { l ->
                            Column(Modifier.padding(vertical = 6.dp)) {
                                Text("${l.speaker}  •  ${Parsing.formatTime(l.timeSec)}", color = C.Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(l.text, fontSize = 15.sp)
                            }
                        }
                    }
                } else {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                        when (tab) {
                            0 -> {
                                Text(fmtDate(m.createdAt) + "  •  ${maxOf(1, m.durationSec / 60)} ${stringResource(R.string.min)}", color = Color.Gray, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(m.summary, fontSize = 16.sp, lineHeight = 24.sp)
                                SectionTitle(stringResource(R.string.files))
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        FileRow(stringResource(R.string.audio_file), m.audioPath, "audio/mp4")
                                        FileRow(stringResource(R.string.transcript_pdf), m.transcriptPdf, "application/pdf")
                                        FileRow(stringResource(R.string.minutes_pdf), m.minutesPdf, "application/pdf")
                                    }
                                }
                            }
                            1 -> {
                                if (m.attendees.isNotEmpty()) {
                                    SectionTitle(stringResource(R.string.attendees))
                                    Text(m.attendees.joinToString("، "))
                                }
                                m.topics.forEach { t ->
                                    SectionTitle(t.title)
                                    t.points.forEach { Text("•  $it", Modifier.padding(vertical = 2.dp), lineHeight = 22.sp) }
                                }
                                if (m.decisions.isNotEmpty()) {
                                    SectionTitle(stringResource(R.string.decisions))
                                    m.decisions.forEach { Text("•  $it", Modifier.padding(vertical = 2.dp), lineHeight = 22.sp) }
                                }
                            }
                            2 -> {
                                if (m.actions.isEmpty()) Text(stringResource(R.string.no_actions), color = Color.Gray)
                                m.actions.forEach { a ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                                        Column(Modifier.padding(14.dp)) {
                                            Text(a.task, fontWeight = FontWeight.Bold)
                                            if (a.owner.isNotBlank()) Text("${stringResource(R.string.owner)}: ${a.owner}", color = Color.Gray, fontSize = 13.sp)
                                            if (a.due.isNotBlank()) Text("${stringResource(R.string.due)}: ${a.due}", color = Color.Gray, fontSize = 13.sp)
                                            if (a.priority.isNotBlank()) Text("${stringResource(R.string.priority)}: ${a.priority}", color = Color.Gray, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Status.ERROR -> Column(Modifier.fillMaxSize().padding(24.dp)) {
                Text(m.statusText, color = C.Red, fontSize = 16.sp)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        ContextCompat.startForegroundService(
                            ctx,
                            Intent(ctx, RecorderService::class.java).setAction(RecorderService.ACTION_PROCESS).putExtra(RecorderService.EXTRA_ID, m.id)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Teal),
                ) { Text(stringResource(R.string.retry)) }
            }
            else -> Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = C.Teal)
                Spacer(Modifier.height(16.dp))
                Text(m.statusText.ifBlank { statusLabel(m.status) }, fontSize = 16.sp)
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            text = { Text(stringResource(R.string.delete_q)) },
            confirmButton = { TextButton(onClick = { confirm = false; Store.delete(ctx, m.id) }) { Text(stringResource(R.string.yes)) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(Store.apiKey) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Header(stringResource(R.string.settings), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            OutlinedTextField(
                value = key, onValueChange = { key = it }, singleLine = true,
                label = { Text(stringResource(R.string.api_key)) }, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = key.isNotBlank() && !busy,
                onClick = {
                    scope.launch {
                        busy = true
                        msg = try {
                            Store.apiKey = key
                            GeminiClient(key.trim()).generate(JSONArray().put(JSONObject().put("text", "Return exactly this JSON: {\"ok\":true}")))
                            ctx.getString(R.string.key_ok)
                        } catch (e: Exception) {
                            ctx.getString(R.string.key_bad) + ": " + (e.message ?: "")
                        }
                        busy = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = C.Teal),
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.save_test)) }
            if (busy) { Spacer(Modifier.height(8.dp)); CircularProgressIndicator(color = C.Teal) }
            if (msg.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(msg, color = if (msg.startsWith(stringResource(R.string.key_ok))) C.Green else C.Red)
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
            }) { Text(stringResource(R.string.get_key)) }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.key_steps), color = Color.Gray, lineHeight = 22.sp)
        }
    }
}
