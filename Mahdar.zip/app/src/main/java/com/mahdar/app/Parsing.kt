package com.mahdar.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Analysis(
    val title: String,
    val summary: String,
    val attendees: List<String>,
    val topics: List<Topic>,
    val decisions: List<String>,
    val actions: List<ActionItem>,
)

object Parsing {
    /** Removes markdown fences / chatter around a JSON payload. */
    fun extractJson(raw: String): String {
        val s = raw.trim()
        val start = s.indexOfFirst { it == '{' || it == '[' }
        val end = s.indexOfLast { it == '}' || it == ']' }
        return if (start in 0 until end) s.substring(start, end + 1) else s
    }

    fun parseTime(s: String): Int {
        val p = s.trim().split(":").map { it.trim().toIntOrNull() ?: return 0 }
        return when (p.size) {
            2 -> p[0] * 60 + p[1]
            3 -> p[0] * 3600 + p[1] * 60 + p[2]
            else -> 0
        }
    }

    fun formatTime(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun parseTranscript(json: String, offsetSec: Int): List<Line> {
        val t = json.trim()
        val arr = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("lines") ?: JSONArray()
        val out = mutableListOf<Line>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val text = o.str("text").trim()
            if (text.isEmpty()) continue
            val sp = o.str("speaker").ifBlank { "Speaker 1" }
            out += Line(sp, offsetSec + parseTime(o.str("start")), text)
        }
        return out
    }

    fun parseAnalysis(json: String): Analysis {
        val o = JSONObject(json)
        val topics = o.optJSONArray("topics")?.let { a ->
            (0 until a.length()).mapNotNull { a.optJSONObject(it) }
                .map { Topic(it.str("title"), it.optJSONArray("points").strings()) }
        } ?: emptyList()
        val actions = o.optJSONArray("actions")?.let { a ->
            (0 until a.length()).mapNotNull { a.optJSONObject(it) }
                .map { ActionItem(it.str("task"), it.str("owner"), it.str("due"), it.str("priority")) }
                .filter { it.task.isNotBlank() }
        } ?: emptyList()
        return Analysis(
            title = o.str("title"), summary = o.str("summary"),
            attendees = o.optJSONArray("attendees").strings(), topics = topics,
            decisions = o.optJSONArray("decisions").strings(), actions = actions,
        )
    }

    /** Pulls the text out of a Gemini generateContent response. */
    fun responseText(body: String): String {
        val o = JSONObject(body)
        val parts = o.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        if (parts == null || parts.length() == 0) {
            throw IllegalStateException(o.optJSONObject("promptFeedback")?.toString() ?: "Empty response")
        }
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString()
    }

    fun errorMessage(body: String): String = try {
        JSONObject(body).getJSONObject("error").optString("message", body.take(200))
    } catch (e: Exception) {
        body.take(200)
    }
}
