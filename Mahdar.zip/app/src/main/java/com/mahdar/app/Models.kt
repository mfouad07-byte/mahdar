package com.mahdar.app

import org.json.JSONArray
import org.json.JSONObject

enum class Status { RECORDING, PROCESSING, DONE, ERROR }

data class Line(val speaker: String, val timeSec: Int, val text: String)
data class ActionItem(val task: String, val owner: String, val due: String, val priority: String)
data class Topic(val title: String, val points: List<String>)

data class Meeting(
    val id: String,
    val title: String,
    val createdAt: Long,
    val durationSec: Int = 0,
    val status: Status = Status.RECORDING,
    val statusText: String = "",
    val audioPath: String = "",
    val transcriptPdf: String = "",
    val minutesPdf: String = "",
    val lines: List<Line> = emptyList(),
    val summary: String = "",
    val attendees: List<String> = emptyList(),
    val topics: List<Topic> = emptyList(),
    val decisions: List<String> = emptyList(),
    val actions: List<ActionItem> = emptyList(),
)

fun List<String>.toJsonArray(): JSONArray = JSONArray().also { a -> forEach { a.put(it) } }

fun JSONArray?.strings(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).map { optString(it) }.filter { it.isNotBlank() && it != "null" }
}

fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key, "")

fun Meeting.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("title", title); put("createdAt", createdAt)
    put("durationSec", durationSec); put("status", status.name); put("statusText", statusText)
    put("audioPath", audioPath); put("transcriptPdf", transcriptPdf); put("minutesPdf", minutesPdf)
    put("summary", summary)
    put("lines", JSONArray().also { a ->
        lines.forEach { a.put(JSONObject().put("s", it.speaker).put("t", it.timeSec).put("x", it.text)) }
    })
    put("attendees", attendees.toJsonArray())
    put("topics", JSONArray().also { a ->
        topics.forEach { a.put(JSONObject().put("t", it.title).put("p", it.points.toJsonArray())) }
    })
    put("decisions", decisions.toJsonArray())
    put("actions", JSONArray().also { a ->
        actions.forEach {
            a.put(JSONObject().put("task", it.task).put("owner", it.owner).put("due", it.due).put("pr", it.priority))
        }
    })
}

fun meetingFromJson(o: JSONObject): Meeting {
    fun <T> arr(name: String, f: (JSONObject) -> T): List<T> {
        val a = o.optJSONArray(name) ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map(f)
    }
    return Meeting(
        id = o.str("id"), title = o.str("title"), createdAt = o.optLong("createdAt"),
        durationSec = o.optInt("durationSec"),
        status = runCatching { Status.valueOf(o.str("status")) }.getOrDefault(Status.ERROR),
        statusText = o.str("statusText"), audioPath = o.str("audioPath"),
        transcriptPdf = o.str("transcriptPdf"), minutesPdf = o.str("minutesPdf"),
        lines = arr("lines") { Line(it.str("s"), it.optInt("t"), it.str("x")) },
        summary = o.str("summary"),
        attendees = o.optJSONArray("attendees").strings(),
        topics = arr("topics") { Topic(it.str("t"), it.optJSONArray("p").strings()) },
        decisions = o.optJSONArray("decisions").strings(),
        actions = arr("actions") { ActionItem(it.str("task"), it.str("owner"), it.str("due"), it.str("pr")) },
    )
}
