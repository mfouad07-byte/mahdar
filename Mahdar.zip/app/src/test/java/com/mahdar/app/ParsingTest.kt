package com.mahdar.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ParsingTest {
    @Test
    fun extractJson_stripsMarkdownFences() {
        assertEquals("[1,2]", Parsing.extractJson("```json\n[1,2]\n```"))
        assertEquals("{\"a\":1}", Parsing.extractJson("Here you go: {\"a\":1} thanks"))
    }

    @Test
    fun time_parsingAndFormatting() {
        assertEquals(75, Parsing.parseTime("01:15"))
        assertEquals(3725, Parsing.parseTime("1:02:05"))
        assertEquals(0, Parsing.parseTime("garbage"))
        assertEquals("01:15", Parsing.formatTime(75))
        assertEquals("1:02:05", Parsing.formatTime(3725))
    }

    @Test
    fun transcript_mixedArabicEnglish_withOffset() {
        val j = """[{"speaker":"Speaker 1","start":"00:05","text":"اجتماع الـ sprint planning"},
            {"speaker":"Speaker 2","start":"01:00","text":"OK تمام، خلينا نبدأ"},
            {"speaker":"Speaker 2","start":"01:10","text":""}]"""
        val l = Parsing.parseTranscript(j, 600)
        assertEquals(2, l.size)
        assertEquals(605, l[0].timeSec)
        assertEquals("اجتماع الـ sprint planning", l[0].text)
        assertEquals("Speaker 2", l[1].speaker)
        assertEquals(660, l[1].timeSec)
    }

    @Test
    fun transcript_emptyArray() {
        assertTrue(Parsing.parseTranscript("[]", 0).isEmpty())
    }

    @Test
    fun analysis_parsesActionsAndHandlesNulls() {
        val j = """{"title":"اجتماع المبيعات","summary":"ملخص","attendees":["Ahmed","Sara"],
            "topics":[{"title":"Q4","points":["a","b"]}],"decisions":["go"],
            "actions":[{"task":"Send offer","owner":"Ahmed","due":"2026-10-10","priority":"High"},
                       {"task":"","owner":null,"due":null,"priority":null},
                       {"task":"Review","owner":null,"due":null,"priority":"Low"}]}"""
        val a = Parsing.parseAnalysis(j)
        assertEquals("اجتماع المبيعات", a.title)
        assertEquals(2, a.actions.size)
        assertEquals("", a.actions[1].owner)
        assertEquals(listOf("a", "b"), a.topics[0].points)
    }

    @Test
    fun responseText_joinsParts() {
        val body = """{"candidates":[{"content":{"parts":[{"text":"[]"}]}}]}"""
        assertEquals("[]", Parsing.responseText(body))
    }

    @Test(expected = IllegalStateException::class)
    fun responseText_blockedResponseThrows() {
        Parsing.responseText("""{"promptFeedback":{"blockReason":"SAFETY"}}""")
    }

    @Test
    fun meeting_jsonRoundTrip() {
        val m = Meeting(
            id = "1", title = "t", createdAt = 5L, status = Status.DONE,
            lines = listOf(Line("S1", 3, "مرحبا hello")),
            topics = listOf(Topic("x", listOf("p"))),
            actions = listOf(ActionItem("do", "me", "soon", "High")),
        )
        val back = meetingFromJson(m.toJson())
        assertEquals(m, back)
    }
}
